This will install GPAC for ARM PocketPC/SmartPhones 2003 Platforms

GPAC is an open source MPEG-4 framework developped by ENST and available at:
	http://gpac.io

WARNING: THIS RELEASE COMES WITH NO WARRANTY, AND MAY EVEN DAMAGE YOUR HANDHELD DEVICE. PLEASE READ CAREFULLY THE LICENSE HEREJOIN
