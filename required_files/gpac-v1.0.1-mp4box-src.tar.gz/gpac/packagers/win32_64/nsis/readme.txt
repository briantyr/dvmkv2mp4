GPAC: NSIS installer manual
==========================

Recommended
-----------

Please execute the "generate_installer.bat" file at the root GPAC directory. The revision and version will be retrieved.


Alternative (developers only)
-----------------------------

Launching the NSIS installer the "bin\win32\release\nsis_install" will generate an unversion installer. The DATE/HOUR will be included in the installer file. Use it in case you're making some experimental developments.
